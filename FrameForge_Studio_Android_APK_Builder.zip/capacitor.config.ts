import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.frameforge.studio',
  appName: 'FrameForge Studio',
  webDir: 'www',
  server: {
    // This wrapper loads the existing hosted app.
    // The app must remain online for the editor to work.
    url: 'https://frameforge-studio-mprqpm.v2.appdeploy.ai/',
    cleartext: false
  },
  android: {
    allowMixedContent: false
  }
};

export default config;
