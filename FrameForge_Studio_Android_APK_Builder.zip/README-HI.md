# FrameForge Studio — Android APK Builder

यह प्रोजेक्ट मौजूदा FrameForge Studio वेब ऐप को Android WebView/Capacitor wrapper में खोलने के लिए है।
यह अभी सीधे APK नहीं है; GitHub Actions इसे build करके APK artifact बनाएगा।

## APK बनाने के स्टेप (मोबाइल से भी)

1. इस ZIP को extract करें।
2. GitHub पर नया repository बनाएं, उदाहरण: `frameforge-studio-android`.
3. ZIP के अंदर की सभी फाइलें repository में upload/commit करें। `.github/workflows/build-apk.yml` भी शामिल होना चाहिए।
4. Repository में **Actions** टैब खोलें।
5. **Build FrameForge Studio APK** workflow चुनें और **Run workflow** दबाएं।
6. Build सफल होने पर उसी workflow run के नीचे **Artifacts** में `FrameForge-Studio-debug-APK` मिलेगा।
7. Artifact ZIP डाउनलोड करके extract करें। अंदर `app-debug.apk` होगा, जिसे अपने Android फोन पर इंस्टॉल कर सकते हैं।

## ज़रूरी सीमाएँ

- यह wrapper मौजूदा ऑनलाइन ऐप URL खोलता है; यह पूरा वेब ऐप APK के अंदर offline bundle नहीं करता।
- ऐप चलाने के लिए इंटरनेट और मौजूदा hosted app का ऑनलाइन होना ज़रूरी है।
- यह **debug APK** है, Play Store के लिए signed release APK नहीं।
- APK बनने से editor में जो सुविधाएँ अभी अधूरी हैं (जैसे वास्तविक MP4 render/export), वे अपने-आप लागू नहीं होंगी।
- अगर GitHub Actions build में Capacitor/Gradle version error आए, तो build log के अनुसार version update करना होगा।
- AppDeploy में कोई नया web version deploy या release नहीं किया गया है।
